import Stack
main = putStrLn show(isEmpty (EmptyStack))
