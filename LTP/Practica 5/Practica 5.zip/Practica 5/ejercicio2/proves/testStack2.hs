import Stack
main = putStrLn (show (top (push 5 empty)))
