import Stack
main = putStrLn (show (push 7 (push 5 empty)))
