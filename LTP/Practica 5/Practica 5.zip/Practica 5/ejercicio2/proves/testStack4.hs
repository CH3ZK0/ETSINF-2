import Stack
main = do
putStrLn (show (pop (push 1 empty)))
putStrLn (show (push 10 (push 5 empty)))


