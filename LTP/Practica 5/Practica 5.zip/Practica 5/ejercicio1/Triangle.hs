module Triangle (area) where
area :: Float->Float->Float
area base altura = (base*altura)/2
