module Circle (area) where
area:: Float->Float
area c = c*c
