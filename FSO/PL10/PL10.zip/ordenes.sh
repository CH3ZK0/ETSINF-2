cd $mxd/minix
mkdir users/maria
cp users/alfonso/f1 users/felipe
mv users/felipe/usuarios bin
rm bin/cat
rm bin/ls
rm usr/prac1
ln bin/sh users/felipe/mish
ln -s users/felipe/f1 usr/f1
